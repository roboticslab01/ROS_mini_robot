#ifndef L298_H
#define L298_H

#define l_fw    7
#define l_bw    8
#define l_pwm   9
#define r_fw    4
#define r_bw    3
#define r_pwm   10

int icr = 0x03ff;

void setupPWM10bit();
void analogWrite10(unsigned char pin, int val);
void motor(int lpwm, int rpwm);

#endif
