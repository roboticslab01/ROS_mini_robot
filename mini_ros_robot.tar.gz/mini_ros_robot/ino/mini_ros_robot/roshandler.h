#ifndef ROSHANDLER_H
#define ROSHANDLER_H

#include <ros.h>
#include <mini_ros_robot/Wheels.h>

ros::NodeHandle nh;

void subs_pwm(const mini_ros_robot::Wheels & dat);

#endif
