#!/usr/bin/env python

from __future__ import print_function

import roslib; roslib.load_manifest('teleop_twist_keyboard')
import rospy

from std_msgs.msg import Int16

import sys, select, termios, tty

msg = """
Reading from the keyboard  and Publishing to Twist!
---------------------------
Moving around:
	q  w  e
	a  s  d 
	z  x  c 

f : increasing speed by 5
g : decreasing speed by 5
h : increasing speed by 100
j : decreasing speed by 100
anything else : stop


CTRL-C to quit
"""

moveBindings = {
		'q':(0.65,1),
		'w':(1,1),
		'e':(1,0.65), 
		'a':(-0.75,0.75),
		's':(0,0),
		'd':(0.75,-0.75),
		'z':(-0.65,-1),
		'x':(-1,-1),
		'c':(-1,-0.65),
		}
pwmBindings = {
		'f':(5),
		'g':(-5),
		'h':(100),
		'j':(-100),
		}

def getKey():
	tty.setraw(sys.stdin.fileno())
	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

if __name__=="__main__":
    	settings = termios.tcgetattr(sys.stdin)

	lft  = rospy.Publisher('l_pwm_val', Int16, queue_size = 16)
	rgt = rospy.Publisher('r_pwm_val', Int16, queue_size = 16)
	rospy.init_node('teleop_controller')
	status = 0
	pwm=500;lpwm=0;rpwm=0
	try:
		print(msg)
		while(1):
			key = getKey()
			if key in moveBindings.keys():
				lpwm = moveBindings[key][0]
				rpwm = moveBindings[key][1]
			elif key in pwmBindings.keys():
				pwm = pwm + pwmBindings[key]
				rospy.loginfo(pwm)
				if(pwm > 1020):
					pwm = 1020
				elif (pwm < 0):
					pwm = 0
			else:
				lpwm = 0;rpwm=0;
				if (key == '\x03'):
					break
			lpwm = lpwm * pwm; rpwm = rpwm * pwm
			lft.publish(lpwm)
			rgt.publish(rpwm)
		
	except Exception as e:
		print(e)

	finally:
		lft.publish(lpwm)
		rgt.publish(rpwm)

    		termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


