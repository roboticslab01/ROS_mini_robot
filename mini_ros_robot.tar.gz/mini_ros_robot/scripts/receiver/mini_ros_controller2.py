#!/usr/bin/env python

import rospy
from krsbi_training.msg import tayo
from mini_ros_robot.msg import Wheels

def callback(data):
	pwm = data.maju.data
	con_data(pwm)

def con_data(value):
	mov.lpwm.data = value
	mov.rpwm.data = value
	pub.publish(mov)
	rospy.loginfo(mov)

if __name__ == "__main__":
	rospy.init_node('data_converter1')
	pub = rospy.Publisher('/mini_robot_ros/pwm_val', Wheels, queue_size=16)
	mov = Wheels()
	try:
		#while not rospy.is_shutdown():
		rospy.Subscriber('tayo_topic', tayo, callback)
			#mov.rpwm.data = rpwms
			#mov.lpwm.data = lpwms
			#pub.publish(mov)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass

