#!/usr/bin/env python

import rospy
from std_msgs.msg import Int16
from mini_ros_robot.msg import Wheels

def callback(data):
	lpwms = data.data
	con_data(1,lpwms)

def callback1(data):
	rpwms = data.data
	con_data(2,rpwms)


def con_data(mode,value):
	if(mode==1):
		mov.lpwm.data = value
	elif(mode==2):
		mov.rpwm.data = value
	pub.publish(mov)
	rospy.loginfo(mov)

if __name__ == "__main__":
	rospy.init_node('data_converter')
	pub = rospy.Publisher('/mini_robot_ros/pwm_val', Wheels, queue_size=16)
	mov = Wheels()
	try:
		#while not rospy.is_shutdown():
		rospy.Subscriber('l_pwm_val', Int16, callback)
		rospy.Subscriber('r_pwm_val', Int16, callback1)
			#mov.rpwm.data = rpwms
			#mov.lpwm.data = lpwms
			#pub.publish(mov)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass

