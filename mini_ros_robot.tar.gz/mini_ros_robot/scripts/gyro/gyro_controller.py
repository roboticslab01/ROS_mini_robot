#!/usr/bin/env python

import rospy
from std_msgs.msg import Int16
from sensor_msgs.msg import Imu

def imu_data(data):
	x = data.orientation.x
	y = data.orientation.y
	imu_to_pwm(x,y)

def imu_to_pwm(in1,in2):
	pwm = 500
	in1 = -10*in1*pwm
	if(in1 < 200) and (in1 > -50):
		in1 = 0
	if(in1>1020):
		in1 = 1020
	elif(in1<-1020):
		in1 = -1020
	lft.publish(in1)
	rgt.publish(in1)

if __name__ == '__main__':
	rospy.init_node('gyro_controller', anonymous=True)
	lft  = rospy.Publisher('l_pwm_val', Int16, queue_size = 16)
	rgt = rospy.Publisher('r_pwm_val', Int16, queue_size = 16)
	try:
		rospy.Subscriber("/android/imu", Imu, imu_data)
		rospy.spin()
	except rospy.ROSInterruptException:
		pass